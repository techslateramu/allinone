import json

def lambda_handler(event, context):
    # TODO implement
    print('This is my Lambda Function')
    if event['Fruit'] == 'Banana':
        return 'Banana Pie'
    elif event['Fruit'] == 'potato':
        return 'This is not a Fruit'
    
    else:
        return 'we dont recognise'
